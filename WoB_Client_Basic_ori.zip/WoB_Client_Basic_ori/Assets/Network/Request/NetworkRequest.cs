public abstract class NetworkRequest {
	
	public GamePacket packet { get; set; }
	public short request_id { get; set; }
}
